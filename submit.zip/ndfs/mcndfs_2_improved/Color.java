package ndfs.mcndfs_2_improved;

/**
 * This enumeration enumerates the possible colors.
 */
public enum Color {

  CYAN, WHITE, RED, BLUE
}
