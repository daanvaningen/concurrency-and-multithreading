package ndfs.nndfs;

/**
 * This enumeration enumerates the possible colors.
 */
public enum Color {

    CYAN, WHITE, RED, BLUE
}
