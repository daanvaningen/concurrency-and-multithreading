package ndfs.mcndfs_1_naive;

import java.util.concurrent.locks.ReentrantLock;
import java.util.HashMap;
import java.util.Map;
import graph.State;

public class SharedData {
  // Shared HashMap for red states
  private volatile Map<State, Boolean> red = new HashMap<State, Boolean>();
  // Shared HashMap for the counter per state
  private volatile Map<State, Integer> count = new HashMap<State, Integer>();
  // Lock for the counter
  private final ReentrantLock Counterlock = new ReentrantLock();
  // Lock for the red states
  private final ReentrantLock Redlock = new ReentrantLock();

  /**
   * Set a the red state to true
   *
   * @param State state to be set to true
   */
  public void setRed (State state) {
    Redlock.lock();
    try {
      this.red.put(state, true);
    } finally {
      Redlock.unlock();
    }
  }

  /**
   * Get the red value of a state
   *
   * @param State state to be retrieved
   */
  public Boolean getRed (State state) {
    Boolean s = false;
    Redlock.lock();
    try {
      s = this.red.get(state);
      if (s == null) s = false;
    } catch (Exception e) {
      System.out.println("getRed Error");
    } finally {
      Redlock.unlock();
    }

    return s;
  }

  /**
   * Change the count of a state
   *
   * @param State state count to be changed
   * @param amount amount to change by (+1, -1)
   */
  public void changeCount (State state, int amount) {
    Counterlock.lock();
    try {
      Integer currentCount = this.count.get(state);
      if (currentCount == null) {
        currentCount = new Integer(amount);
      } else {
        currentCount = new Integer(currentCount + amount);
      }
      this.count.put(state, currentCount);
    } catch (Exception e) {
      System.out.println("exception");
    } finally {
      Counterlock.unlock();
    }
  }

  /**
   * Get the count of a state
   *
   * @param State state count to be retrieved
   */
  public Integer getCount (State state) {
    Integer currentCount = this.count.get(state);
    if (currentCount == null) return 0;
    return currentCount;
  }
}
