package ndfs.mcndfs_1_naive;

/**
 * This enumeration enumerates the possible colors.
 */
public enum Color {

  CYAN, WHITE, RED, BLUE
}
