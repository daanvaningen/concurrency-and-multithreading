/**
 * This package contains an example of using
 * java.util.concurrent.ExecutorService.
 */

package example_callable;